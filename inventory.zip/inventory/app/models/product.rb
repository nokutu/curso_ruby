class Product < ActiveRecord::Base
  has_many :petitions
end
