class HomeController < ApplicationController
  def index
    @petitions = Petition.all
    @products = Product.order("lendable is true desc, lent is true desc, name asc").page(params[:page]).per(10)
  end
end
