class SessionsController < ApplicationController
end
